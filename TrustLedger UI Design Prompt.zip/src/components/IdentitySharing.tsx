import { ArrowLeft, QrCode, Copy, CheckCircle2, Share2, Shield } from 'lucide-react';
import { useState } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import type { Screen } from '../App';

interface IdentitySharingProps {
  onNavigate: (screen: Screen) => void;
}

export function IdentitySharing({ onNavigate }: IdentitySharingProps) {
  const [copied, setCopied] = useState(false);
  const identityHash = '0x7f9a3c2d8e5b1f4a9c6d2e8b5f1a7c3d9e6b2f8a5c1d7e4b9f6a3c8d5e2b1f4a';

  const handleCopy = () => {
    navigator.clipboard.writeText(identityHash);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-white border-b border-slate-200">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => onNavigate('dashboard')}
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <div className="flex items-center gap-2">
              <Shield className="w-7 h-7 text-indigo-600" />
              <span className="text-2xl text-slate-900">TrustLedger</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-8 max-w-3xl">
        <div className="mb-8">
          <h1 className="text-3xl text-slate-900 mb-2">Share Identity</h1>
          <p className="text-slate-600">
            Share your verified identity with others using a QR code
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* QR Code Card */}
          <Card className="p-8 rounded-2xl border-slate-200 shadow-sm">
            <div className="text-center">
              <h3 className="text-lg text-slate-900 mb-6">Verification QR Code</h3>
              
              {/* QR Code Placeholder */}
              <div className="w-64 h-64 mx-auto bg-white border-4 border-slate-200 rounded-2xl p-4 mb-6 flex items-center justify-center">
                <div className="w-full h-full bg-gradient-to-br from-indigo-100 via-purple-100 to-blue-100 rounded-xl flex items-center justify-center">
                  <QrCode className="w-32 h-32 text-indigo-600" />
                </div>
              </div>

              <p className="text-slate-600 mb-4">
                Scan to verify identity on-chain
              </p>

              <Button 
                variant="outline" 
                className="w-full"
                onClick={handleCopy}
              >
                {copied ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 mr-2 text-green-600" />
                    Copied!
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 mr-2" />
                    Copy QR Data
                  </>
                )}
              </Button>
            </div>
          </Card>

          {/* Info & Actions */}
          <div className="space-y-6">
            <Card className="p-6 rounded-2xl border-slate-200 shadow-sm">
              <h3 className="text-lg text-slate-900 mb-4">Identity Hash</h3>
              <div className="bg-slate-50 rounded-xl p-4 mb-4">
                <p className="text-slate-600 break-all font-mono text-sm">
                  {identityHash}
                </p>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                className="w-full"
                onClick={handleCopy}
              >
                {copied ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 mr-2 text-green-600" />
                    Copied!
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 mr-2" />
                    Copy Hash
                  </>
                )}
              </Button>
            </Card>

            <Card className="p-6 rounded-2xl border-slate-200 shadow-sm">
              <h3 className="text-lg text-slate-900 mb-4">Share Options</h3>
              <div className="space-y-3">
                <Button 
                  variant="outline" 
                  className="w-full justify-start"
                >
                  <Share2 className="w-4 h-4 mr-2" />
                  Share via Email
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start"
                >
                  <Share2 className="w-4 h-4 mr-2" />
                  Share via Link
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start"
                >
                  <Share2 className="w-4 h-4 mr-2" />
                  Generate Temporary Pass
                </Button>
              </div>
            </Card>

            <Card className="p-6 rounded-2xl border-indigo-100 bg-indigo-50 shadow-sm">
              <div className="flex gap-3">
                <Shield className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-slate-900 mb-1">Privacy Protected</h4>
                  <p className="text-slate-600">
                    Only your verification status is shared. Personal details remain encrypted on-chain.
                  </p>
                </div>
              </div>
            </Card>
          </div>
        </div>

        {/* Usage Instructions */}
        <Card className="p-6 rounded-2xl border-slate-200 shadow-sm mt-6">
          <h3 className="text-lg text-slate-900 mb-4">How to Use</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <div className="w-10 h-10 bg-indigo-100 rounded-xl flex items-center justify-center mb-3">
                <span className="text-indigo-600">1</span>
              </div>
              <h4 className="text-slate-900 mb-2">Generate QR Code</h4>
              <p className="text-slate-600">Your identity hash is encoded into a scannable QR code</p>
            </div>
            <div>
              <div className="w-10 h-10 bg-purple-100 rounded-xl flex items-center justify-center mb-3">
                <span className="text-purple-600">2</span>
              </div>
              <h4 className="text-slate-900 mb-2">Share Securely</h4>
              <p className="text-slate-600">Share the QR code or hash with trusted parties</p>
            </div>
            <div>
              <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center mb-3">
                <span className="text-blue-600">3</span>
              </div>
              <h4 className="text-slate-900 mb-2">Instant Verification</h4>
              <p className="text-slate-600">Recipients verify your identity on the blockchain</p>
            </div>
          </div>
        </Card>
      </main>
    </div>
  );
}

import { Wallet, Shield, Network, Lock, CheckCircle2, Zap } from 'lucide-react';
import { Button } from './ui/button';

interface LandingPageProps {
  onConnectWallet: () => void;
  onLearnMore: () => void;
}

export function LandingPage({ onConnectWallet, onLearnMore }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-600 via-purple-600 to-blue-600 relative overflow-hidden">
      {/* Decorative Elements */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 left-20 w-72 h-72 bg-white rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-white rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 container mx-auto px-6 py-16">
        {/* Header */}
        <nav className="flex justify-between items-center mb-20">
          <div className="flex items-center gap-2">
            <Shield className="w-8 h-8 text-white" />
            <span className="text-white text-2xl">TrustLedger</span>
          </div>
          <Button 
            variant="outline" 
            className="bg-white/10 border-white/20 text-white hover:bg-white/20"
            onClick={onConnectWallet}
          >
            <Wallet className="w-4 h-4 mr-2" />
            Connect Wallet
          </Button>
        </nav>

        {/* Hero Section */}
        <div className="max-w-4xl mx-auto text-center mt-20">
          <h1 className="text-6xl text-white mb-6">
            TrustLedger
          </h1>
          <p className="text-2xl text-white/90 mb-12">
            Decentralized, Secure & Portable KYC Identity
          </p>

          <div className="flex gap-4 justify-center mb-20">
            <Button 
              size="lg" 
              className="bg-white text-indigo-600 hover:bg-white/90"
              onClick={onConnectWallet}
            >
              <Wallet className="w-5 h-5 mr-2" />
              Connect Wallet
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              className="bg-white/10 border-white/20 text-white hover:bg-white/20"
              onClick={onLearnMore}
            >
              Learn More
            </Button>
          </div>

          {/* Features Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-16">
            <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-3xl p-8">
              <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-white text-xl mb-2">Secure</h3>
              <p className="text-white/70">
                Zero-knowledge proofs protect your identity data on-chain
              </p>
            </div>

            <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-3xl p-8">
              <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Network className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-white text-xl mb-2">Decentralized</h3>
              <p className="text-white/70">
                No central authority controls your identity verification
              </p>
            </div>

            <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-3xl p-8">
              <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Lock className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-white text-xl mb-2">Portable</h3>
              <p className="text-white/70">
                Use your verified identity across multiple platforms
              </p>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-8 mt-16 max-w-2xl mx-auto">
            <div>
              <div className="text-4xl text-white mb-2">50K+</div>
              <div className="text-white/70">Verified Users</div>
            </div>
            <div>
              <div className="text-4xl text-white mb-2">200+</div>
              <div className="text-white/70">Partner Organizations</div>
            </div>
            <div>
              <div className="text-4xl text-white mb-2">99.9%</div>
              <div className="text-white/70">Uptime</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

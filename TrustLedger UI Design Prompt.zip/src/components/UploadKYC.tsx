import { useState } from 'react';
import { ArrowLeft, Upload, FileText, Image as ImageIcon, CheckCircle2, Shield } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Progress } from './ui/progress';
import type { Screen } from '../App';

interface UploadKYCProps {
  onNavigate: (screen: Screen) => void;
}

export function UploadKYC({ onNavigate }: UploadKYCProps) {
  const [uploadProgress, setUploadProgress] = useState({
    aadhaar: 0,
    pan: 0,
    selfie: 0
  });

  const handleFileUpload = (type: 'aadhaar' | 'pan' | 'selfie') => {
    // Simulate upload
    let progress = 0;
    const interval = setInterval(() => {
      progress += 10;
      setUploadProgress(prev => ({ ...prev, [type]: progress }));
      if (progress >= 100) {
        clearInterval(interval);
      }
    }, 100);
  };

  const allUploaded = uploadProgress.aadhaar === 100 && 
                      uploadProgress.pan === 100 && 
                      uploadProgress.selfie === 100;

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-white border-b border-slate-200">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => onNavigate('dashboard')}
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <div className="flex items-center gap-2">
              <Shield className="w-7 h-7 text-indigo-600" />
              <span className="text-2xl text-slate-900">TrustLedger</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-8 max-w-4xl">
        <div className="mb-8">
          <h1 className="text-3xl text-slate-900 mb-2">Upload KYC Documents</h1>
          <p className="text-slate-600">
            Upload your identity documents to generate a blockchain-verified identity hash
          </p>
        </div>

        <div className="space-y-6">
          {/* Aadhaar/Passport Upload */}
          <Card className="p-6 rounded-2xl border-slate-200 shadow-sm">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-lg text-slate-900 mb-1">Aadhaar / Passport</h3>
                <p className="text-slate-600">Government-issued ID document</p>
              </div>
              <div className="w-12 h-12 bg-indigo-100 rounded-xl flex items-center justify-center">
                <FileText className="w-6 h-6 text-indigo-600" />
              </div>
            </div>

            {uploadProgress.aadhaar === 0 ? (
              <div 
                className="border-2 border-dashed border-slate-300 rounded-xl p-12 text-center hover:border-indigo-400 hover:bg-indigo-50/50 transition-colors cursor-pointer"
                onClick={() => handleFileUpload('aadhaar')}
              >
                <Upload className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                <p className="text-slate-600 mb-2">Click to upload or drag and drop</p>
                <p className="text-slate-400">PDF, PNG, JPG (max 10MB)</p>
              </div>
            ) : uploadProgress.aadhaar === 100 ? (
              <div className="border-2 border-green-200 bg-green-50 rounded-xl p-8 text-center">
                <CheckCircle2 className="w-12 h-12 text-green-600 mx-auto mb-3" />
                <p className="text-green-700">Document uploaded successfully</p>
              </div>
            ) : (
              <div className="p-4">
                <Progress value={uploadProgress.aadhaar} className="mb-2" />
                <p className="text-slate-600 text-center">Uploading... {uploadProgress.aadhaar}%</p>
              </div>
            )}
          </Card>

          {/* PAN Card Upload */}
          <Card className="p-6 rounded-2xl border-slate-200 shadow-sm">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-lg text-slate-900 mb-1">PAN Card</h3>
                <p className="text-slate-600">Tax identification document</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                <FileText className="w-6 h-6 text-purple-600" />
              </div>
            </div>

            {uploadProgress.pan === 0 ? (
              <div 
                className="border-2 border-dashed border-slate-300 rounded-xl p-12 text-center hover:border-purple-400 hover:bg-purple-50/50 transition-colors cursor-pointer"
                onClick={() => handleFileUpload('pan')}
              >
                <Upload className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                <p className="text-slate-600 mb-2">Click to upload or drag and drop</p>
                <p className="text-slate-400">PDF, PNG, JPG (max 10MB)</p>
              </div>
            ) : uploadProgress.pan === 100 ? (
              <div className="border-2 border-green-200 bg-green-50 rounded-xl p-8 text-center">
                <CheckCircle2 className="w-12 h-12 text-green-600 mx-auto mb-3" />
                <p className="text-green-700">Document uploaded successfully</p>
              </div>
            ) : (
              <div className="p-4">
                <Progress value={uploadProgress.pan} className="mb-2" />
                <p className="text-slate-600 text-center">Uploading... {uploadProgress.pan}%</p>
              </div>
            )}
          </Card>

          {/* Selfie Upload */}
          <Card className="p-6 rounded-2xl border-slate-200 shadow-sm">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-lg text-slate-900 mb-1">Selfie Upload</h3>
                <p className="text-slate-600">Photo for identity verification</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                <ImageIcon className="w-6 h-6 text-blue-600" />
              </div>
            </div>

            {uploadProgress.selfie === 0 ? (
              <div 
                className="border-2 border-dashed border-slate-300 rounded-xl p-12 text-center hover:border-blue-400 hover:bg-blue-50/50 transition-colors cursor-pointer"
                onClick={() => handleFileUpload('selfie')}
              >
                <Upload className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                <p className="text-slate-600 mb-2">Click to upload or drag and drop</p>
                <p className="text-slate-400">PNG, JPG (max 5MB)</p>
              </div>
            ) : uploadProgress.selfie === 100 ? (
              <div className="border-2 border-green-200 bg-green-50 rounded-xl p-8 text-center">
                <CheckCircle2 className="w-12 h-12 text-green-600 mx-auto mb-3" />
                <p className="text-green-700">Photo uploaded successfully</p>
              </div>
            ) : (
              <div className="p-4">
                <Progress value={uploadProgress.selfie} className="mb-2" />
                <p className="text-slate-600 text-center">Uploading... {uploadProgress.selfie}%</p>
              </div>
            )}
          </Card>

          {/* Action Button */}
          <div className="pt-4">
            <Button 
              size="lg"
              className="w-full bg-indigo-600 hover:bg-indigo-700"
              disabled={!allUploaded}
              onClick={() => onNavigate('verification')}
            >
              <Shield className="w-5 h-5 mr-2" />
              Generate Blockchain Hash
            </Button>
            {!allUploaded && (
              <p className="text-slate-500 text-center mt-3">
                Please upload all required documents
              </p>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}

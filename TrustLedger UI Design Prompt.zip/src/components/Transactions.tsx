import { ArrowLeft, ExternalLink, Upload, CheckCircle2, Share2, Clock, Shield } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import type { Screen } from '../App';

interface TransactionsProps {
  onNavigate: (screen: Screen) => void;
}

export function Transactions({ onNavigate }: TransactionsProps) {
  const transactions = [
    {
      hash: '0x8f2a...9d3c',
      type: 'Upload',
      status: 'Confirmed',
      timestamp: '2025-11-23 10:23:45',
      blockNumber: '18234567',
      icon: Upload,
      color: 'indigo'
    },
    {
      hash: '0x3b7e...2f1a',
      type: 'Verify',
      status: 'Confirmed',
      timestamp: '2025-11-22 15:12:33',
      blockNumber: '18234012',
      icon: CheckCircle2,
      color: 'green'
    },
    {
      hash: '0x9c4d...7a8b',
      type: 'Share',
      status: 'Confirmed',
      timestamp: '2025-11-22 09:45:21',
      blockNumber: '18233891',
      icon: Share2,
      color: 'purple'
    },
    {
      hash: '0x5e1f...3c9d',
      type: 'Upload',
      status: 'Confirmed',
      timestamp: '2025-11-21 14:56:12',
      blockNumber: '18232456',
      icon: Upload,
      color: 'indigo'
    },
    {
      hash: '0xa6b2...4d8e',
      type: 'Verify',
      status: 'Confirmed',
      timestamp: '2025-11-20 11:34:28',
      blockNumber: '18231234',
      icon: CheckCircle2,
      color: 'green'
    },
    {
      hash: '0x2d9c...6f7a',
      type: 'Share',
      status: 'Pending',
      timestamp: '2025-11-23 14:15:42',
      blockNumber: '-',
      icon: Share2,
      color: 'yellow'
    },
  ];

  const getStatusBadge = (status: string) => {
    if (status === 'Confirmed') {
      return <Badge className="bg-green-100 text-green-700 hover:bg-green-100">Confirmed</Badge>;
    }
    return <Badge className="bg-yellow-100 text-yellow-700 hover:bg-yellow-100">Pending</Badge>;
  };

  const getTypeIcon = (icon: any, color: string) => {
    const Icon = icon;
    const colorMap: { [key: string]: string } = {
      indigo: 'bg-indigo-100 text-indigo-600',
      green: 'bg-green-100 text-green-600',
      purple: 'bg-purple-100 text-purple-600',
      yellow: 'bg-yellow-100 text-yellow-600'
    };
    
    return (
      <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${colorMap[color]}`}>
        <Icon className="w-5 h-5" />
      </div>
    );
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-white border-b border-slate-200">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => onNavigate('dashboard')}
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <div className="flex items-center gap-2">
              <Shield className="w-7 h-7 text-indigo-600" />
              <span className="text-2xl text-slate-900">TrustLedger</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-8 max-w-5xl">
        <div className="mb-8">
          <h1 className="text-3xl text-slate-900 mb-2">Transaction History</h1>
          <p className="text-slate-600">
            View all your on-chain identity verification transactions
          </p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="p-6 rounded-2xl border-slate-200 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-600 mb-1">Total Transactions</p>
                <p className="text-3xl text-slate-900">6</p>
              </div>
              <div className="w-12 h-12 bg-indigo-100 rounded-2xl flex items-center justify-center">
                <Shield className="w-6 h-6 text-indigo-600" />
              </div>
            </div>
          </Card>

          <Card className="p-6 rounded-2xl border-slate-200 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-600 mb-1">Confirmed</p>
                <p className="text-3xl text-slate-900">5</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-2xl flex items-center justify-center">
                <CheckCircle2 className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </Card>

          <Card className="p-6 rounded-2xl border-slate-200 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-600 mb-1">Pending</p>
                <p className="text-3xl text-slate-900">1</p>
              </div>
              <div className="w-12 h-12 bg-yellow-100 rounded-2xl flex items-center justify-center">
                <Clock className="w-6 h-6 text-yellow-600" />
              </div>
            </div>
          </Card>
        </div>

        {/* Transactions Table */}
        <Card className="rounded-2xl border-slate-200 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                  <th className="text-left py-4 px-6 text-slate-600">Type</th>
                  <th className="text-left py-4 px-6 text-slate-600">Tx Hash</th>
                  <th className="text-left py-4 px-6 text-slate-600">Status</th>
                  <th className="text-left py-4 px-6 text-slate-600">Timestamp</th>
                  <th className="text-left py-4 px-6 text-slate-600">Block</th>
                  <th className="text-left py-4 px-6 text-slate-600"></th>
                </tr>
              </thead>
              <tbody>
                {transactions.map((tx, index) => (
                  <tr 
                    key={index} 
                    className="border-b border-slate-100 hover:bg-slate-50 transition-colors"
                  >
                    <td className="py-4 px-6">
                      <div className="flex items-center gap-3">
                        {getTypeIcon(tx.icon, tx.color)}
                        <span className="text-slate-900">{tx.type}</span>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <code className="text-slate-600 bg-slate-100 px-2 py-1 rounded">
                        {tx.hash}
                      </code>
                    </td>
                    <td className="py-4 px-6">
                      {getStatusBadge(tx.status)}
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center gap-2 text-slate-600">
                        <Clock className="w-4 h-4" />
                        {tx.timestamp}
                      </div>
                    </td>
                    <td className="py-4 px-6 text-slate-600">
                      {tx.blockNumber}
                    </td>
                    <td className="py-4 px-6">
                      <Button 
                        variant="ghost" 
                        size="sm"
                        className="text-indigo-600 hover:text-indigo-700"
                      >
                        <ExternalLink className="w-4 h-4" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        {/* Info Card */}
        <Card className="p-6 rounded-2xl border-indigo-100 bg-indigo-50 mt-6">
          <div className="flex gap-3">
            <Shield className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-slate-900 mb-1">Blockchain Explorer</h4>
              <p className="text-slate-600">
                Click the external link icon to view transaction details on the blockchain explorer. 
                All transactions are permanently recorded and verifiable on-chain.
              </p>
            </div>
          </div>
        </Card>
      </main>
    </div>
  );
}

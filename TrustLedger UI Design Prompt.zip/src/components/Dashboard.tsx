import { User, Shield, Database, Key, Upload, FileCheck, QrCode, List } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import type { Screen } from '../App';

interface DashboardProps {
  onNavigate: (screen: Screen) => void;
  walletAddress: string;
}

export function Dashboard({ onNavigate, walletAddress }: DashboardProps) {
  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-white border-b border-slate-200">
        <div className="container mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <Shield className="w-7 h-7 text-indigo-600" />
              <span className="text-2xl text-slate-900">TrustLedger</span>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-slate-600">
                {walletAddress}
              </div>
              <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-full flex items-center justify-center">
                <User className="w-5 h-5 text-white" />
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white border-b border-slate-200">
        <div className="container mx-auto px-6">
          <div className="flex gap-1">
            <button 
              className="px-4 py-3 text-indigo-600 border-b-2 border-indigo-600"
              onClick={() => onNavigate('dashboard')}
            >
              Dashboard
            </button>
            <button 
              className="px-4 py-3 text-slate-600 hover:text-slate-900"
              onClick={() => onNavigate('verification')}
            >
              Verification
            </button>
            <button 
              className="px-4 py-3 text-slate-600 hover:text-slate-900"
              onClick={() => onNavigate('access')}
            >
              Access Control
            </button>
            <button 
              className="px-4 py-3 text-slate-600 hover:text-slate-900"
              onClick={() => onNavigate('transactions')}
            >
              Transactions
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-8">
        <h1 className="text-3xl text-slate-900 mb-8">Dashboard</h1>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="p-6 rounded-2xl border-slate-200 shadow-sm">
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 bg-green-100 rounded-2xl flex items-center justify-center">
                <Shield className="w-6 h-6 text-green-600" />
              </div>
              <Badge className="bg-green-100 text-green-700 hover:bg-green-100">Verified</Badge>
            </div>
            <h3 className="text-slate-600 mb-1">KYC Status</h3>
            <p className="text-2xl text-slate-900">Verified</p>
          </Card>

          <Card className="p-6 rounded-2xl border-slate-200 shadow-sm">
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 bg-indigo-100 rounded-2xl flex items-center justify-center">
                <Database className="w-6 h-6 text-indigo-600" />
              </div>
            </div>
            <h3 className="text-slate-600 mb-1">Identity Hash</h3>
            <p className="text-slate-900 truncate">0x7f9a...4b2e</p>
          </Card>

          <Card className="p-6 rounded-2xl border-slate-200 shadow-sm">
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 bg-purple-100 rounded-2xl flex items-center justify-center">
                <Key className="w-6 h-6 text-purple-600" />
              </div>
            </div>
            <h3 className="text-slate-600 mb-1">Access Permissions</h3>
            <p className="text-2xl text-slate-900">3 Active</p>
          </Card>
        </div>

        {/* Action Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="p-8 rounded-2xl border-slate-200 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-14 h-14 bg-indigo-100 rounded-2xl flex items-center justify-center mb-4">
              <Upload className="w-7 h-7 text-indigo-600" />
            </div>
            <h3 className="text-xl text-slate-900 mb-2">Upload KYC Documents</h3>
            <p className="text-slate-600 mb-6">
              Submit your identity documents for verification on the blockchain
            </p>
            <Button 
              className="bg-indigo-600 hover:bg-indigo-700"
              onClick={() => onNavigate('upload')}
            >
              Upload Documents
            </Button>
          </Card>

          <Card className="p-8 rounded-2xl border-slate-200 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-14 h-14 bg-purple-100 rounded-2xl flex items-center justify-center mb-4">
              <QrCode className="w-7 h-7 text-purple-600" />
            </div>
            <h3 className="text-xl text-slate-900 mb-2">Share Identity</h3>
            <p className="text-slate-600 mb-6">
              Generate a QR code to share your verified identity
            </p>
            <Button 
              variant="outline"
              className="border-purple-200 text-purple-600 hover:bg-purple-50"
              onClick={() => onNavigate('identity')}
            >
              Generate QR Code
            </Button>
          </Card>

          <Card className="p-8 rounded-2xl border-slate-200 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-14 h-14 bg-blue-100 rounded-2xl flex items-center justify-center mb-4">
              <FileCheck className="w-7 h-7 text-blue-600" />
            </div>
            <h3 className="text-xl text-slate-900 mb-2">Verification Status</h3>
            <p className="text-slate-600 mb-6">
              Check the status of your identity verification process
            </p>
            <Button 
              variant="outline"
              className="border-blue-200 text-blue-600 hover:bg-blue-50"
              onClick={() => onNavigate('verification')}
            >
              View Status
            </Button>
          </Card>

          <Card className="p-8 rounded-2xl border-slate-200 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-14 h-14 bg-green-100 rounded-2xl flex items-center justify-center mb-4">
              <List className="w-7 h-7 text-green-600" />
            </div>
            <h3 className="text-xl text-slate-900 mb-2">Transaction History</h3>
            <p className="text-slate-600 mb-6">
              View all your on-chain verification transactions
            </p>
            <Button 
              variant="outline"
              className="border-green-200 text-green-600 hover:bg-green-50"
              onClick={() => onNavigate('transactions')}
            >
              View Transactions
            </Button>
          </Card>
        </div>
      </main>
    </div>
  );
}

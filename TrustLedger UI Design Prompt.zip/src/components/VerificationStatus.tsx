import { ArrowLeft, CheckCircle2, Clock, Upload, Hash, Shield } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import type { Screen } from '../App';

interface VerificationStatusProps {
  onNavigate: (screen: Screen) => void;
}

export function VerificationStatus({ onNavigate }: VerificationStatusProps) {
  const verificationSteps = [
    {
      title: 'Document Uploaded',
      description: 'KYC documents received and encrypted',
      status: 'completed',
      timestamp: '2025-11-20 14:23:15',
      icon: Upload
    },
    {
      title: 'Hash Generated',
      description: 'Blockchain identity hash created',
      status: 'completed',
      timestamp: '2025-11-20 14:25:42',
      icon: Hash
    },
    {
      title: 'Validator Node Approval',
      description: 'Verification by decentralized validators',
      status: 'completed',
      timestamp: '2025-11-21 09:12:33',
      icon: Shield
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-white border-b border-slate-200">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => onNavigate('dashboard')}
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <div className="flex items-center gap-2">
              <Shield className="w-7 h-7 text-indigo-600" />
              <span className="text-2xl text-slate-900">TrustLedger</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-8 max-w-3xl">
        <div className="mb-8">
          <h1 className="text-3xl text-slate-900 mb-2">Verification Status</h1>
          <p className="text-slate-600">
            Track the progress of your identity verification
          </p>
        </div>

        {/* Status Badge */}
        <Card className="p-8 rounded-2xl border-slate-200 shadow-sm mb-8 text-center">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle2 className="w-10 h-10 text-green-600" />
          </div>
          <Badge className="bg-green-100 text-green-700 hover:bg-green-100 mb-3">
            VERIFIED
          </Badge>
          <h2 className="text-2xl text-slate-900 mb-2">Identity Verified</h2>
          <p className="text-slate-600 max-w-md mx-auto">
            Your identity has been successfully verified on the blockchain and is ready to use
          </p>
        </Card>

        {/* Timeline */}
        <Card className="p-8 rounded-2xl border-slate-200 shadow-sm">
          <h3 className="text-xl text-slate-900 mb-6">Verification Timeline</h3>
          
          <div className="space-y-6">
            {verificationSteps.map((step, index) => {
              const Icon = step.icon;
              const isLast = index === verificationSteps.length - 1;
              
              return (
                <div key={index} className="flex gap-4">
                  <div className="flex flex-col items-center">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      step.status === 'completed' 
                        ? 'bg-green-100' 
                        : 'bg-yellow-100'
                    }`}>
                      <Icon className={`w-5 h-5 ${
                        step.status === 'completed' 
                          ? 'text-green-600' 
                          : 'text-yellow-600'
                      }`} />
                    </div>
                    {!isLast && (
                      <div className={`w-0.5 h-12 ${
                        step.status === 'completed' 
                          ? 'bg-green-200' 
                          : 'bg-slate-200'
                      }`} />
                    )}
                  </div>
                  
                  <div className="flex-1 pb-8">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="text-slate-900">{step.title}</h4>
                      {step.status === 'completed' && (
                        <CheckCircle2 className="w-4 h-4 text-green-600" />
                      )}
                      {step.status === 'pending' && (
                        <Clock className="w-4 h-4 text-yellow-600" />
                      )}
                    </div>
                    <p className="text-slate-600 mb-2">{step.description}</p>
                    <p className="text-slate-400">{step.timestamp}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>

        {/* Additional Info */}
        <Card className="p-6 rounded-2xl border-slate-200 shadow-sm mt-6 bg-indigo-50 border-indigo-100">
          <div className="flex gap-4">
            <div className="w-10 h-10 bg-indigo-100 rounded-xl flex items-center justify-center shrink-0">
              <Hash className="w-5 h-5 text-indigo-600" />
            </div>
            <div>
              <h4 className="text-slate-900 mb-1">Your Identity Hash</h4>
              <p className="text-slate-600 break-all">
                0x7f9a3c2d8e5b1f4a9c6d2e8b5f1a7c3d9e6b2f8a5c1d7e4b9f6a3c8d5e2b1f4a
              </p>
            </div>
          </div>
        </Card>

        {/* Actions */}
        <div className="flex gap-4 mt-8">
          <Button 
            className="flex-1 bg-indigo-600 hover:bg-indigo-700"
            onClick={() => onNavigate('identity')}
          >
            Share Identity
          </Button>
          <Button 
            variant="outline"
            className="flex-1"
            onClick={() => onNavigate('transactions')}
          >
            View Transactions
          </Button>
        </div>
      </main>
    </div>
  );
}

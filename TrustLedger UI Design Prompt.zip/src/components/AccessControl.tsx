import { useState } from 'react';
import { ArrowLeft, Building2, Clock, CheckCircle2, Shield, AlertCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Switch } from './ui/switch';
import { Badge } from './ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import type { Screen } from '../App';

interface AccessControlProps {
  onNavigate: (screen: Screen) => void;
}

interface AccessEntity {
  id: string;
  name: string;
  type: string;
  icon: string;
  hasAccess: boolean;
  requestPending?: boolean;
}

export function AccessControl({ onNavigate }: AccessControlProps) {
  const [showRequestDialog, setShowRequestDialog] = useState(false);
  const [pendingRequest, setPendingRequest] = useState<string>('');
  
  const [entities, setEntities] = useState<AccessEntity[]>([
    { id: '1', name: 'HDFC Bank', type: 'Banking', icon: '🏦', hasAccess: true },
    { id: '2', name: 'Coinbase Exchange', type: 'Crypto Exchange', icon: '💱', hasAccess: true },
    { id: '3', name: 'Upstox Trading', type: 'Investment', icon: '📈', hasAccess: false },
    { id: '4', name: 'PayPal', type: 'Payment Gateway', icon: '💳', hasAccess: true },
    { id: '5', name: 'Binance', type: 'Crypto Exchange', icon: '🪙', hasAccess: false, requestPending: true },
  ]);

  const accessHistory = [
    { org: 'HDFC Bank', timestamp: '2025-11-23 10:23:45', type: 'Full Access', status: 'active' },
    { org: 'Coinbase Exchange', timestamp: '2025-11-22 15:12:33', type: 'Verification Only', status: 'active' },
    { org: 'PayPal', timestamp: '2025-11-21 09:45:21', type: 'Full Access', status: 'active' },
    { org: 'Kraken Exchange', timestamp: '2025-11-18 14:56:12', type: 'Temporary Access', status: 'expired' },
  ];

  const handleToggleAccess = (id: string) => {
    setEntities(entities.map(e => 
      e.id === id ? { ...e, hasAccess: !e.hasAccess } : e
    ));
  };

  const handleApproveRequest = () => {
    setEntities(entities.map(e => 
      e.id === '5' ? { ...e, hasAccess: true, requestPending: false } : e
    ));
    setShowRequestDialog(false);
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-white border-b border-slate-200">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => onNavigate('dashboard')}
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <div className="flex items-center gap-2">
              <Shield className="w-7 h-7 text-indigo-600" />
              <span className="text-2xl text-slate-900">TrustLedger</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-8 max-w-5xl">
        <div className="mb-8">
          <h1 className="text-3xl text-slate-900 mb-2">Access Control</h1>
          <p className="text-slate-600">
            Manage which organizations can access your verified identity
          </p>
        </div>

        {/* Pending Request Alert */}
        {entities.some(e => e.requestPending) && (
          <Card className="p-4 rounded-2xl border-yellow-200 bg-yellow-50 mb-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <AlertCircle className="w-5 h-5 text-yellow-600" />
                <div>
                  <p className="text-slate-900">New Access Request</p>
                  <p className="text-slate-600">Binance is requesting temporary access to your KYC data</p>
                </div>
              </div>
              <Button 
                size="sm"
                className="bg-yellow-600 hover:bg-yellow-700"
                onClick={() => setShowRequestDialog(true)}
              >
                Review Request
              </Button>
            </div>
          </Card>
        )}

        {/* Connected Entities */}
        <Card className="p-6 rounded-2xl border-slate-200 shadow-sm mb-8">
          <h3 className="text-xl text-slate-900 mb-6">Connected Organizations</h3>
          
          <div className="space-y-4">
            {entities.map((entity) => (
              <div 
                key={entity.id}
                className="flex items-center justify-between p-4 rounded-xl border border-slate-200 hover:bg-slate-50 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center text-2xl">
                    {entity.icon}
                  </div>
                  <div>
                    <h4 className="text-slate-900">{entity.name}</h4>
                    <p className="text-slate-600">{entity.type}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-4">
                  {entity.requestPending ? (
                    <Badge className="bg-yellow-100 text-yellow-700 hover:bg-yellow-100">
                      Pending
                    </Badge>
                  ) : entity.hasAccess ? (
                    <Badge className="bg-green-100 text-green-700 hover:bg-green-100">
                      Active
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="text-slate-600">
                      Inactive
                    </Badge>
                  )}
                  <Switch 
                    checked={entity.hasAccess}
                    onCheckedChange={() => handleToggleAccess(entity.id)}
                    disabled={entity.requestPending}
                  />
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Permission History */}
        <Card className="p-6 rounded-2xl border-slate-200 shadow-sm">
          <h3 className="text-xl text-slate-900 mb-6">Permission History</h3>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-200">
                  <th className="text-left py-3 px-4 text-slate-600">Organization</th>
                  <th className="text-left py-3 px-4 text-slate-600">Timestamp</th>
                  <th className="text-left py-3 px-4 text-slate-600">Access Type</th>
                  <th className="text-left py-3 px-4 text-slate-600">Status</th>
                </tr>
              </thead>
              <tbody>
                {accessHistory.map((record, index) => (
                  <tr key={index} className="border-b border-slate-100 hover:bg-slate-50">
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-2">
                        <Building2 className="w-4 h-4 text-slate-400" />
                        <span className="text-slate-900">{record.org}</span>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-2 text-slate-600">
                        <Clock className="w-4 h-4" />
                        {record.timestamp}
                      </div>
                    </td>
                    <td className="py-4 px-4 text-slate-600">{record.type}</td>
                    <td className="py-4 px-4">
                      {record.status === 'active' ? (
                        <Badge className="bg-green-100 text-green-700 hover:bg-green-100">
                          Active
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="text-slate-600">
                          Expired
                        </Badge>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </main>

      {/* Access Request Dialog */}
      <Dialog open={showRequestDialog} onOpenChange={setShowRequestDialog}>
        <DialogContent className="rounded-2xl">
          <DialogHeader>
            <DialogTitle>New Access Request</DialogTitle>
            <DialogDescription>
              Review the access request from Binance
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 bg-yellow-100 rounded-2xl flex items-center justify-center text-3xl">
                🪙
              </div>
              <div>
                <h4 className="text-lg text-slate-900">Binance</h4>
                <p className="text-slate-600">Crypto Exchange</p>
              </div>
            </div>
            
            <div className="space-y-3 text-slate-600">
              <p><strong>Requesting:</strong> Temporary KYC data access</p>
              <p><strong>Duration:</strong> 24 hours</p>
              <p><strong>Purpose:</strong> Account verification for trading</p>
              <p><strong>Data Access:</strong> Name, ID verification status, country</p>
            </div>
          </div>

          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowRequestDialog(false)}
            >
              Deny
            </Button>
            <Button 
              className="bg-indigo-600 hover:bg-indigo-700"
              onClick={handleApproveRequest}
            >
              Approve Access
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

import { useState } from 'react';
import { LandingPage } from './components/LandingPage';
import { Dashboard } from './components/Dashboard';
import { UploadKYC } from './components/UploadKYC';
import { VerificationStatus } from './components/VerificationStatus';
import { AccessControl } from './components/AccessControl';
import { IdentitySharing } from './components/IdentitySharing';
import { Transactions } from './components/Transactions';

export type Screen = 'landing' | 'dashboard' | 'upload' | 'verification' | 'access' | 'identity' | 'transactions';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('landing');
  const [isWalletConnected, setIsWalletConnected] = useState(false);

  const handleConnectWallet = () => {
    setIsWalletConnected(true);
    setCurrentScreen('dashboard');
  };

  const navigateTo = (screen: Screen) => {
    setCurrentScreen(screen);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {currentScreen === 'landing' && (
        <LandingPage onConnectWallet={handleConnectWallet} onLearnMore={() => {}} />
      )}
      {currentScreen === 'dashboard' && (
        <Dashboard onNavigate={navigateTo} walletAddress="0x742d...3A9F" />
      )}
      {currentScreen === 'upload' && (
        <UploadKYC onNavigate={navigateTo} />
      )}
      {currentScreen === 'verification' && (
        <VerificationStatus onNavigate={navigateTo} />
      )}
      {currentScreen === 'access' && (
        <AccessControl onNavigate={navigateTo} />
      )}
      {currentScreen === 'identity' && (
        <IdentitySharing onNavigate={navigateTo} />
      )}
      {currentScreen === 'transactions' && (
        <Transactions onNavigate={navigateTo} />
      )}
    </div>
  );
}


  # TrustLedger UI Design Prompt

  This is a code bundle for TrustLedger UI Design Prompt. The original project is available at https://www.figma.com/design/BlohxquJq1VwRxG0IHVrHv/TrustLedger-UI-Design-Prompt.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  